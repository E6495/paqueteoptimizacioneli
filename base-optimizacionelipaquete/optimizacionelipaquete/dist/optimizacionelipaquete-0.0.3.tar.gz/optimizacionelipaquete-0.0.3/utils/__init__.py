from .graficas import grafica_2d_con_restricciones
from .graficas import grafica_2d_no_restricciones
from .graficas import plot_rangos_minimos
